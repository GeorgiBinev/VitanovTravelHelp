import React from "react";
import "../index.css";

const currentYear = new Date().getFullYear();

const Footer = () => (
  <footer className="footer">
    © {currentYear} Пътна Помощ Витанов Транс EOOД
  </footer>
);

export default Footer;
