import React from "react";
import { Link } from "react-router-dom";
import "../index.css";

const Header = () => (
  <header className="header">
    {" "}
    Пътна Помощ Витанов Транс
    <nav>
      <ul>
        <li>
          <Link to="/">За нас</Link>
        </li>
        <li>
          <Link to="/gallery">Галерия</Link>
        </li>
        <li>
          <Link to="/faq">Полезно</Link>
        </li>
      </ul>
    </nav>
  </header>
);

export default Header;
