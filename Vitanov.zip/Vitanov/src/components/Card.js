import React from "react";
import "../index.css"

const Card = ({ service }) => (
  <div className="card">
    <img src={service.image} alt={service.name} className="card-image" />
    <h3>{service.name}</h3>
    <p>{service.description}</p>
  </div>
);

export default Card;
