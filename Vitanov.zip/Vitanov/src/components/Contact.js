import React from "react";
import "../index.css"

const Contact = () => (
  <div className="contact">
    <h2>Контакт</h2>
    <p>Работим денонощно! Свържете се с нас за пътна помощ по всяко време!</p>
    <ul>
      <li><strong>Телефон:</strong> +359 89 507 2172</li>
      <li><strong>Email:</strong> vitanov_trans@abv.bg</li>
      <li><strong>Адрес:</strong> Пловдив, България</li>
    </ul>
  </div>
);

export default Contact;
