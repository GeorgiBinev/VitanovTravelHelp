import React from "react";
import Card from "./Card";
import Contact from "./Contact";
import "../index.css"

const services = [
  { id: 1, name: "ПЪТНА ПОМОЩ", description: "24 часа, 7 дни в седмицата, по всяко време можете да ни повикате! Предлагаме бързо и надеждно съдействие на място при всякакви пътни ситуации.", image: "/servicesImages/1.webp" },
  { id: 2, name: "РЕПАТРАК", description: "Превоз и транспорт на закъсали, повредени или новозакупени автомобили, камиони, бусове, кемпери, каравани, строителна и селскостопанска техника, както и друг вид товари.", image: "/servicesImages/2.png" },
  { id: 3, name: "СМЯНА НА ГУМА", description: "На разположение сме 24/7 за бърза и професионална смяна на гума на място. Независимо от ситуацията, осигуряваме сигурност и удобство за вашето пътуване.", image: "/servicesImages/3.png" },
  { id: 4, name: "ДОСТАВЯНЕ НА ГОРИВО", description: "Ако сте останали без гориво, можем да го доставим до вас – бензин, дизел или газ. Бърза и сигурна услуга за леки автомобили, джипове, бусове, ванове и други.", image: "/servicesImages/4.webp" },
  { id: 5, name: "ПОДАВАНЕ НА ТОК", description: "Осигуряваме подаване на стартов ток и смяна на акумулатор при нужда. Бързо реагираме на повиквания и ви помагаме да продължите пътуването си без проблеми.", image: "/servicesImages/5.png" },
  { id: 6, name: "АВАРИЙНИ УСЛУГИ", description: "Специализирани сме във вадене на закъсали автомобили в сняг, кал, дерета или канавки. Разполагаме с техника за всякакви терени и осигуряваме бърза помощ.", image: "/servicesImages/6.webp" },
];

const Grid = () => (
  <div className="main">
    <div className="grid-container">
      <div className="grid">
        {services.map(service => (
          <Card key={service.id} service={service} />
        ))}
      </div>
    </div>
    <Contact />
  </div>
);

export default Grid;
