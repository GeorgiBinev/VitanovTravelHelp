import React, { useState } from "react";
import "../index.css"

const Gallery = () => {
  const [images] = useState([
    "/galleryImages/1.jpg",
    "/galleryImages/2.jpg",
    "/galleryImages/3.jpg",
    "/galleryImages/4.jpg",
    "/galleryImages/5.jpg",
    "/galleryImages/6.jpg",
    "/galleryImages/7.jpg",
    "/galleryImages/8.jpg",
    "/galleryImages/9.jpg",
    "/galleryImages/10.jpg",
    "/galleryImages/11.jpg",
    "/galleryImages/12.jpg",
  ]);

  const imagesPerPage = 4;
  const [currentPage, setCurrentPage] = useState(0);

  const handleNext = () => {
    setCurrentPage((prevPage) => (prevPage + 1) % (images.length / imagesPerPage));
  };

  const handlePrev = () => {
    setCurrentPage((prevPage) => (prevPage - 1 + (images.length / imagesPerPage)) % (images.length / imagesPerPage));
  };

  const startIndex = currentPage * imagesPerPage;
  const currentImages = images.slice(startIndex, startIndex + imagesPerPage);

  return (
    <div className="gallery-wrapper">
      <div className="gallery-container">
        {currentImages.map((img, index) => (
          <div key={index} className="gallery-item">
            <img src={img} alt={`Gallery ${startIndex + index + 1}`} className="gallery-image" />
          </div>
        ))}
      </div>
      <div className="gallery-controls">
        <button onClick={handlePrev} className="gallery-button">Предишна</button>
        <button onClick={handleNext} className="gallery-button">Следваща</button>
      </div>
    </div>
  );
};

export default Gallery;
