import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Header from "./components/Header";
import Grid from "./components/Grid";
import Footer from "./components/Footer";
import Gallery from "./components/Gallery";
// import Contact from "./components/Contact";
import FAQComponent from "./components/FAQ";
import "./App.css";

//https://putnapomosht-24-7.com/

const App = () => (
  <Router>
    <div className="container">
      <Header />
      <Routes>
        <Route path="/" element={<Grid />}></Route>
        <Route path="/gallery" element={<Gallery />}></Route>
        <Route path="/faq" element={<FAQComponent />}></Route>
      </Routes>
      <Footer />
    </div>
  </Router>
);

export default App;
